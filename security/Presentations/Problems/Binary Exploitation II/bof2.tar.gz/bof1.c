// Compile this with:
// gcc -fno-stack-protector -z execstack -o bof1 -m32 bof1.c

#include <stdio.h>

void vuln() {
    /*
        This time, your mission is to get a shell.
        (I recommend http://shell-storm.org/shellcode/files/shellcode-841.php)

        When you're doing this from the command line, run it like this:
        ([print your shellcode here]; cat) | ./bof1
        This ensures the shell will stay open and not immediately close.

        When you get a shell, you can run commands.
        Try running "ls" and see if you get a listing of files.
        Ctrl-C when you're done using it.

        In a CTF, you would normally "cat" a flag that
        only the owner of the binary can read.
        (The binary would be setup so it runs as the owner.)
    */

    char buf[64] = {0};
    gets(buf);

    ((void(*)())buf)(); // Execute the code in buf.
}

int main() {
    vuln();
}
