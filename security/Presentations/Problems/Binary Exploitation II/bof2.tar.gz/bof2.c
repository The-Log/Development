// Compile this with:
// gcc -fno-stack-protector -z execstack -o bof2 -m32 bof2.c

#include <stdio.h>

void vuln() {
    /*
        This time, the program won't automatically call the buffer for you.
        You'll need to overwrite the return address!

        This is a good opportunity to learn how to script an exploit.
        You don't know where buf is located until you run the program,
        so you need a way to get its output and use that in your input.

        I recommend learning how to use pwntools:
        https://pwntools.readthedocs.org/en/latest/

        You can install it with this terminal command:
        pip install git+https://github.com/Gallopsled/pwntools#egg=pwntools

        Your python script will look something like:

        from pwn import *
        p = process('./bof2')
        # Get output and create your exploit here here...
        # Use p.recv() to get its output and
        # p.sendline(exploit) to send your exploit to it.
        p.interactive()
    */

    char buf[64] = {0};
    printf("buf is located at %p\n",buf);
    gets(buf);
}

int main() {
    vuln();
}
