// Compile this with:
// gcc -z execstack -o bof4 -m32 bof4.c

#include <stdio.h>

void target() {
    // Call this!
    printf("Congrats!\n");
}

void vuln() {
    /*
        This time, there's a stack protector!
        Luckily, you have a way to print values on the stack.
        You'll also need to script this one!
    */

    printf("What's the offset?\n");
    int s;
    scanf("%d",&s); // Read offset (play around with this one!)
    getchar(); // This gets rid of the newline from your input. Don't worry about it.

    printf("0x%08x\n", *(&s+s) ); // Print the value found at an offset from s.
    fflush(stdout);

    printf("Buffer:\n");
    char buf[8] = {0};
    gets(buf);
}

int main() {
    vuln();
}

