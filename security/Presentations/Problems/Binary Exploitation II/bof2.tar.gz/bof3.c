// Compile this with:
// gcc -fno-stack-protector -z execstack -o bof3 -m32 bof3.c

#include <stdio.h>

void vuln() {
    /*
        This time, you don't have a buffer that's large enough!
        You'll need to put your shellcode in an environment variable,
        and overwrite the return address!

        When you're working from the terminal, use this to set one:
        export EGG=$([your command to print the shellcode])

        I recommend making a *huge* NOP sled at the beginning,
        so you can guess the return address.

        You can use GDB to find out roughly where you need to return to.
    */

    char buf[4] = {0};
    gets(buf);
}

int main() {
    vuln();
}

