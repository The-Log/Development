// Compile this with:
// gcc -fno-stack-protector -z execstack -o bof1 -m32 bof1.c

#include <stdio.h>

void vuln() {
    int i = 0; // 4 bytes (32-bit code)
    char buf2[8] = {0};
    gets(buf2);
    if (i != 0) {
        printf("Congrats!\n"); // Get here!
    } else {
        printf("Try again!\n");
    }
}

int main() {
    vuln();
}
