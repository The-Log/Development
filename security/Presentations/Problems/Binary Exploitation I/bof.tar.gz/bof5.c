// Compile this with:
// gcc -fno-stack-protector -z execstack -o bof5 -m32 bof5.c

#include <stdio.h>

// You can find the address of this function with:
// objdump -t bof5
// The first column should have the address.
void target() {
    // Get here!
    printf("Congrats!\n");
}

void vuln() {
    // Try overwriting EIP!
    // gdb may be helpful.
    char buf[8] = {0};
    gets(buf);
}

int main() {
    vuln();
}
