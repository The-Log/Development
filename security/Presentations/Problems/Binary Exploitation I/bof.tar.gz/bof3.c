// Compile this with:
// gcc -fno-stack-protector -z execstack -o bof3 -m32 bof3.c

#include <stdio.h>

void vuln() {
    int i = 0; // 4 bytes (32-bit code)
    char buf2[8] = {0};
    gets(buf2);
    // Beware! Linux is little-endian!
    // You may need to reverse the string!
    if (i == 0x41424344) { // This is ASCII for ABCD.
        printf("Congrats!\n"); // Get here!
    } else {
        printf("Try again!\n");
    }
}

int main() {
    vuln();
}
