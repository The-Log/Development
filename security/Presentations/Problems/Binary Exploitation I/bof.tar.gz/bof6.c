// Compile this with:
// gcc -fno-stack-protector -z execstack -o bof6 -m32 bof6.c

#include <stdio.h>

int i = 0;

void vuln() {
    // You can't overwrite the value of i,
    // and you don't have a function to jump to,
    // but can you still jump to the printf?

    // You can view a disassembly of the code with:
    // objdump -d bof5

    char buf[8] = {0};
    gets(buf);
    if (i != 0) {
        // Get here!
        printf("Congrats!\n");
    }
}

int main() {
    vuln();
}
