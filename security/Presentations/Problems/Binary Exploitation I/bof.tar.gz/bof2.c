// Compile this with:
// gcc -fno-stack-protector -z execstack -o bof2 -m32 bof2.c

#include <stdio.h>

void vuln() {
    int i = 0; // 4 bytes (32-bit code)
    char buf2[8] = {0};
    gets(buf2);
    if (i == 0x42424242) { // This is ascii for BBBB.
        printf("Congrats!\n"); // Get here!
    } else {
        printf("Try again!\n");
    }
}

int main() {
    vuln();
}
