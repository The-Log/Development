// Compile this with:
// gcc -fno-stack-protector -z execstack -o bof4 -m32 bof4.c

#include <stdio.h>

void vuln() {
    int i = 0; // 4 bytes (32-bit code)
    char buf2[8] = {0};
    gets(buf2);
    // Beware! Linux is little-endian!
    // You may need to reverse your input!
    if (i == 0x01020304) { // You'll need a way to input raw bytes.
        printf("Congrats!\n"); // Get here!
    } else {
        printf("Try again!\n");
    }
}

int main() {
    vuln();
}
